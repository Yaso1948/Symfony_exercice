<?php

namespace App\Controller;

use App\Entity\Partie;
use App\Form\EntredatesType;
use App\Form\PartieType;
use App\Repository\PartieRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class PartieController extends AbstractController
{
    #[Route('/partie', name: 'app_partie')]
    public function index(): Response
    {
        return $this->render('partie/index.html.twig', [
            'controller_name' => 'PartieController',
        ]);
    }
    #[Route('/listpartie', name: 'partie_list')]
    public function show(PartieRepository $pr): Response
    {
        $parties=$pr->findAll();
        return $this->render('partie/partie_list.html.twig', [
            'parties' => $parties,
        ]);
    }
    #[Route('/addpartie', name: 'add_partie')]
    public function add_partie(ManagerRegistry $manager,Request $req): Response
    {
        $em=$manager->getManager();
        $parties=new Partie();
        $form=$this->createForm(PartieType::class,$parties);
        $form->handleRequest($req);
        if($form->isSubmitted() && $form->isValid()){
        $em->persist($parties);
        $em->flush();
        return $this->redirectToRoute('partie_list');
        }
        return $this->render('partie/Addpartie.html.twig', [
            'formaddpartie' => $form->createView(),
        ]);
        
    }
    #[Route('/updatepartie/{id}', name: 'update_partie')]
    public function update_product($id,ManagerRegistry $manager,Request $req,PartieRepository $rep): Response
    {
        $em = $manager->getManager();
        $parties = $rep->find($id);
        $form = $this->createForm(PartieType::class, $parties);
        $form->handleRequest($req);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($parties);
            $em->flush();
            return $this->redirectToRoute('partie_list');
        
        }
        return $this->render('partie/updatepartie.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/partieintervalle', name: 'interval_partie')]
    public function partie_interval(PartieRepository $pr,Request $req): Response
    {
        $form=$this->createform(EntredatesType::class);
        $form->handleRequest($req);
        $data=$form->getData();
        if($form->isSubmitted()){
            $PED=$pr->findPartiesentreDates($data[0],$data[1]);
            return $this->render('partie/partie_list.html.twig', [
                'parties' => $PED,
            ]);    
        }
        return $this->render('partie/partieintervalleform.html.twig', [
            'form' => $form->createView(),
        ]);
    }
     #[Route('/filterparties', name: 'filterparties')]
    public function rechercher_dates_entre_intervalles(Request $request, PartieRepository $rep): Response
    {
       
        $datedebut = new \DateTime($request->query->get('datedebut', '2013-01-01'));
        $datefin = new \DateTime($request->query->get('datefin', '2024-12-31'));

       
        $filteredParties = $rep->findPartiesentreDates($datedebut, $datefin);

        return $this->render('partie/FLParties.html.twig', [
            'tabpartie' => $filteredParties,
        ]);
    }
    

}
