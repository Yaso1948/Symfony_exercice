<?php

namespace App\Controller;

use App\Entity\Joueur;
use App\Form\JoueurType;
use App\Repository\JoueurRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class JoueurController extends AbstractController
{
    #[Route('/joueur', name: 'app_joueur')]
    public function index(): Response
    {
        return $this->render('joueur/index.html.twig', [
            'controller_name' => 'JoueurController',
        ]);
    }
    #[Route('/listjoueur', name: 'joueur_list')]
    public function show(JoueurRepository $jr): Response
    {
        $joueurs=$jr->findAll();
        return $this->render('joueur/list_joueurs.html.twig', [
            'joueurs' => $joueurs,
        ]);
    }
    #[Route('/addjoueur', name: 'add_joueur')]
    public function add_product(ManagerRegistry $manager,Request $req): Response
    {
        $em=$manager->getManager();
        $joueurs=new Joueur();
        $form=$this->createForm(JoueurType::class,$joueurs);
        $form->handleRequest($req);
        if($form->isSubmitted() && $form->isValid()){
        $em->persist($joueurs);
        $em->flush();
        return $this->redirectToRoute('joueur_list');
        }
        return $this->render('joueur/Addjoueur.html.twig', [
            'formaddjoueur' => $form->createView(),
        ]);  
    }
    #[Route('/deletejoueur{id}', name: 'delete_joueur')]
    public function delete_joueur($id,ManagerRegistry $manager,JoueurRepository $jr): Response
    {
        $em=$manager->getManager();
        $data_to_delete=$jr->find($id);
        $em->remove($data_to_delete);
        $em->flush();
        return $this->redirectToRoute('joueur_list');
    }
}
