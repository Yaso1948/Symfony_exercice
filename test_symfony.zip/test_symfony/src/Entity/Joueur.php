<?php

namespace App\Entity;

use App\Repository\JoueurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: JoueurRepository::class)]
class Joueur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column]
    private ?bool $status = null;

    /**
     * @var Collection<int, partie>
     */
    #[ORM\OneToMany(targetEntity: Partie::class, mappedBy: 'joueur')]
    private Collection $dates_de_jeux;

    public function __construct()
    {
        $this->dates_de_jeux = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;

        return $this;
    }

    public function isStatus(): ?bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): static
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return Collection<int, partie>
     */
    public function getDatesDeJeux(): Collection
    {
        return $this->dates_de_jeux;
    }

    public function addDatesDeJeux(partie $datesDeJeux): static
    {
        if (!$this->dates_de_jeux->contains($datesDeJeux)) {
            $this->dates_de_jeux->add($datesDeJeux);
            $datesDeJeux->setJoueur($this);
        }

        return $this;
    }

    public function removeDatesDeJeux(partie $datesDeJeux): static
    {
        if ($this->dates_de_jeux->removeElement($datesDeJeux)) {
            // set the owning side to null (unless already changed)
            if ($datesDeJeux->getJoueur() === $this) {
                $datesDeJeux->setJoueur(null);
            }
        }

        return $this;
    }
}
